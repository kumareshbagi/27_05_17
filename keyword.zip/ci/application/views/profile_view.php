<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>keyword bank</title>
	<link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.css"); ?>">
	<link href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/datatables/css/dataTables.bootstrap.css')?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/bootstrap/css/new.css')?>" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-default" role="navigation">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="<?php echo base_url(); ?>index.php/home">KeyWord Bank</a>
		</div>
		<div class="collapse navbar-collapse" id="navbar1">
			<ul class="nav navbar-nav navbar-right">
				<?php if ($this->session->userdata('login')){ ?>
				<li><p class="navbar-text">Hello <?php echo $this->session->userdata('uname'); ?></p></li>
				<li><a href="<?php echo base_url(); ?>index.php/home/logout">Log Out</a></li>
				<?php } else { ?>
				<li><a href="<?php echo base_url(); ?>index.php/login">Login</a></li>
				<?php } ?>
			</ul>
		</div>
	</div>
</nav>

<form method="post">
<input type="text" id="keyword" placeholder="Enter keyword"/>
<input type="button" id="submit" onclick="save();" value="save" />
</form>

<br>
<br>
<div class="container">
	<div class="left-div left-text">
		<div class="something">
		     <input name="search_data" id="search_data" type="text" placeholder="Search" onkeyup="ajaxSearch();"/>
		     <div id="suggestions">
		         <div id="autoSuggestionsList"></div>
		     </div>
		</div>
	</div>
	<div class="right-div right-text">
		<p>dfvfvfdvfrs</p>
	</div>
</div>
</div>

<script type="text/javascript">

function save()
{

   var keyword = $("#keyword").val();
	 var key = {keyword: keyword};
	 // ajax adding data to database
			$.ajax({
				url : "<?php echo ('http://localhost/ci/index.php/Key/key_add')?>",
				type: "POST",
				data: key,
				dataType: "JSON",
				success: function(data)
				{
					 //if success close modal and reload ajax table
					// $('#modal_form').modal('hide');
					location.reload();// for reload a page
				},
				error: function (jqXHR, textStatus, errorThrown)
				{
						alert('Error adding data');
				}
		});

}

function ajaxSearch() {
            var input_data = $('#search_data').val();
            if (input_data.length === 0) {
                $('#suggestions').hide();
            } else {

                var post_data = {
                    'search_data': input_data,
                    '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                };

                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url(); ?>index.php/Search/autocomplete",
                    data: post_data,
                    success: function(data) {
                        // return success
                        if (data.length > 0) {
                            $('#suggestions').show();
                            $('#autoSuggestionsList').addClass('auto_list');
                            $('#autoSuggestionsList').html(data);
                        }
                    }
                });

            }
        }


</script>
<script type="text/javascript" src="<?php echo base_url("assets/js/jquery-1.10.2.js"); ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/js/bootstrap.js"); ?>"></script>

</body>
</html>
