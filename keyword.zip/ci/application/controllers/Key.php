<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Key extends CI_Controller {



	 public function __construct()
	 	{
	 		parent::__construct();
			$this->load->helper('url');
	 		$this->load->model('Key_model');
	 	}

	public function key_add()
		{

			$data = array(
        'keyword' => $this->input->post('keyword'),
			);
      //  $data = $this->input->post("keyword");
			$insert = $this->Key_model->key_add($data);
			echo json_encode(array("status" => TRUE));
		}

}
