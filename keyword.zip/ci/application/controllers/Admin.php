<?php
class Admin extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form','url','html'));
		$this->load->library(array('session', 'form_validation'));
		$this->load->database();
		$this->load->model('User_model');
	}
    public function index()
    {
		// get form input
		$name = $this->input->post("name");
        $pwd = $this->input->post("pwd");

		// form validation
		$this->form_validation->set_rules("name", "name");
		$this->form_validation->set_rules("pwd", "pwd");

		if ($this->form_validation->run() == FALSE)
        {
			// validation fail
			$this->load->view('admin_view');
		}
		else
		{
			// check for admin credentials
			$uresult = $this->User_model->get_admin($name, $pwd);
			if (count($uresult) > 0)
			{
				// set session
				$sess_data = array('login' => TRUE, 'name' => $uresult[0]->name, 'pwd' => $uresult[0]->id);
				$this->session->set_userdata($sess_data);
				redirect("profile/index");
			}
			else
			{
				$this->session->set_flashdata('msg', '<div class="alert alert-danger text-center">Wrong Name or Password!</div>');
				redirect('Admin/index');
			}
		}
    }
}
