<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Add extends CI_Controller {



	 public function __construct()
	 	{
	 		parent::__construct();
			$this->load->helper('url');
	 		$this->load->model('Add_model');
	 	}


	public function index()
	{

		$data['user']=$this->Add_model->get_all_users();
		$this->load->view('add_view',$data);
	}
	public function user_add()
		{
			$data = array(
        'fname' => $this->input->post('fname'),
        'lname' => $this->input->post('lname'),
        'email' => $this->input->post('email'),
				'password' => $this->input->post('password'),
        'role' => $this->input->post('role'),
				);
			$insert = $this->Add_model->user_add($data);
			echo json_encode(array("status" => TRUE));
		}
		public function ajax_edit($id)
		{
			$data = $this->Add_model->get_by_id($id);



			echo json_encode($data);
		}

		public function user_update()
	{
		$data = array(
				'fname' => $this->input->post('fname'),
				'lname' => $this->input->post('lname'),
				'email' => $this->input->post('email'),
				'role' => $this->input->post('role'),
			);
		$this->Add_model->user_update(array('id' => $this->input->post('id')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function user_delete($id)
	{
		$this->Add_model->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}



}
