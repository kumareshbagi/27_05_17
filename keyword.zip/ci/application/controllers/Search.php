<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Search extends CI_Controller {

	 public function __construct()
	 	{
	 		parent::__construct();
			$this->load->helper('url');
	 		$this->load->model('Search_model');
	 	}

    public function autocomplete()
  {
       // load model
      // $this->load->model('Search_model');

       $search_data = $this->input->post('search_data');

       $result = $this->Search_model->get_autocomplete($search_data);

       if (!empty($result))
       {
            foreach ($result as $row):
                 echo "<li><a href='#'>" . $row->name . "</a></li>";
            endforeach;
       }
       else
       {
             echo "<li> <em> Not found ... </em> </li>";
       }
   }

}
