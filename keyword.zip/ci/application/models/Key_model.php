<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Key_model extends CI_Model
{

	var $table = 'keyword';


	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function key_add($data)
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}


}
