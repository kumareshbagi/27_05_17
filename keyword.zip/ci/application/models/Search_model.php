<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Search_model extends CI_Model
{

	//var $table = 'keyword';


	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

  public function get_autocomplete($search_data)
  {
      $this->db->select('name, kid');
      $this->db->like('name', $search_data);

      return $this->db->get('keyword', 10)->result();
  }

}
